import numpy as np

def get_next_state_4(rows, cols, end_x, end_y, non_terminal_reward, terminal_reward, column_wind, stochastic_wind, state_x, state_y, action):
        
        wind_disp = column_wind[state_y]
        if wind_disp and stochastic_wind:
            wind_disp += np.random.choice(np.array([-1, 0, 1]))            

        # next state acc to action
        if action == 0:
            # top
            final_x = max(min(state_x+1+wind_disp, rows-1), 0)
            final_y = state_y            

        elif action == 1:
            # right
            final_y = min(state_y+1, cols-1)
            final_x = max(min(state_x + wind_disp, rows-1), 0)
            
        elif action == 2:
            # bottom
            final_x = max(min(state_x-1+wind_disp, rows-1), 0)
            final_y = state_y

        elif action == 3:
            # left
            final_y = max(state_y-1, 0)
            final_x = max(min(state_x + wind_disp, rows-1), 0)
            
        if final_x == end_x and final_y == end_y:
            reward = terminal_reward
        else:
            reward = non_terminal_reward

        return final_x*cols+final_y, reward


def get_next_state_8(rows, cols, end_x, end_y, non_terminal_reward, terminal_reward, column_wind, stochastic_wind, state_x, state_y, action):
        
        wind_disp = column_wind[state_y]
        if wind_disp and stochastic_wind:
            wind_disp += np.random.choice(np.array([-1, 0, 1]))
        # 4 original moves        
        if action == 0:
            # top
            final_x = max(min(state_x+1+wind_disp, rows-1), 0)
            final_y = state_y            

        elif action == 2:
            # right
            final_y = min(state_y+1, cols-1)
            final_x = max(min(state_x + wind_disp, rows-1), 0)
            
        elif action == 4:
            # bottom
            final_x = max(min(state_x-1+wind_disp, rows-1), 0)
            final_y = state_y

        elif action == 6:
            # left
            final_y = max(state_y-1, 0)
            final_x = max(min(state_x + wind_disp, rows-1), 0)

        elif action == 1:
            # top right
            final_x = max(min(state_x+1+wind_disp, rows-1), 0)
            final_y = min(state_y+1, cols-1)
          
        elif action == 3:
            # right bottom
            final_y = min(state_y+1, cols-1)
            final_x = max(min(state_x-1+wind_disp, rows-1), 0)            

        elif action == 5:
            # bottom left
            final_x = max(min(state_x-1+wind_disp, rows-1), 0)
            final_y = max(0, state_y-1)            
        
        elif action == 7:
            # up left
            final_y = max(state_y-1, 0)
            final_x = max(min(state_x+1+wind_disp, rows-1), 0)
            
        if final_x == end_x and final_y == end_y:
            reward = terminal_reward
        else:
            reward = non_terminal_reward

        return final_x*cols+final_y, reward